package com.example.Customer_1;

public interface CustomerService {

	 public Customer  GetCustomer(String s1);
}
