package com.example.Customer_1;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerController {

	
	@Autowired
	private CustomerService cs;
	
	@RequestMapping("/customer/{simid}")
	public Customer getCustomer(@PathVariable ("simid")String s1)
	{
		
	
		Customer c=cs.GetCustomer(s1)  ;
		
		List<Customer>l1=List.of(c);
		
		
		
		System.out.println(c.getEmail());
		
		return c;
	}
	
	
}
