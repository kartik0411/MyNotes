package com.example.Customer_1;

import java.util.List;

import org.springframework.stereotype.Service;

//import com.SimActivation1.SimActivation1.Customers;

@Service
public class CustomerServiceImpl implements CustomerService {

	
	
	List<Customer>  l1=List.of(
			
			new Customer("1234567891234567","1990-12-12","smith@abc.com","Smith","John","Adhar","1","1","Karnataka"),
			new Customer("1234567891234567","1990-12-12","smith@abc.com","Smith","John","Adhar","1","1","Karnataka"),
			new Customer("1234567891234567","1990-12-12","smith@abc.com","Smith","John","Adhar","1","1","Karnataka")
			);
	public boolean checkforchar(char ch)
	{
		if((int)ch-(int)'a'>26 || (int)ch-(int)'a'<0)
			return true;
		return false;
	}
	public boolean checkforemail(String s1)
	{
		char [] ch=s1.toCharArray();
		boolean ok=true;
		int start = 0;
		for(int i=0;i<ch.length;i++)
		{
			if(ch[i]=='@')
				{
				ok=false;
				start=i;
				break;
				
				}
		}
		if(ok==true)
		{
			return false;
			
		}
		ok=true;
		for(int i=start;i<ch.length;i++)
		{
			if(ch[i]=='.')
			{
				start=i;
				ok=false;
				break;
			}
		}
		if(ok==true)
			return false;
		if(ch.length-start<2 && ch.length-start>4)
		{
			return false;
		}
		
		return true;
	}
	public boolean checkfordate(String s1)
	{
		char [] ch1=s1.toCharArray();
		if(ch1[4]!='-' && ch1[7]!='-')
		{
			return false;
		}
		
		for(int i=0;i<ch1.length;i++)
		{
			if(i!=4 && i!=7)
			{
				if((int)ch1[i]-(int)'0' >9 || (int)ch1[i]-(int)'0' <0)
				{
					return false;
				}
					
			}
		}
		return true;
	}
	
	public Customer GetCustomer(String s1)
	{
		
		
		
	//	List<Customer> lc=
		Customer c=new Customer();
		
		for(Customer ct:l1)
		{
			if(ct.getSimId().equals(s1))
			{
				c=ct;
				return c;
				
			}
		}
		return null;
		
	}
	
	
	
	
	

}
