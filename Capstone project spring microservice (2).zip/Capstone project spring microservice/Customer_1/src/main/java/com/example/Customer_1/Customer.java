package com.example.Customer_1;

public class Customer {
	public Customer() {
		// TODO Auto-generated constructor stub
	}
	private String Cid;
	private String Dob;
	private String Email;
	private String Fname;
	private String Lname;
	private String IdType;
	private String AddressId;
	private String SimId;
	private String State;
	public String getCid() {
		return Cid;
	}
	public void setCid(String cid) {
		Cid = cid;
	}
	public String getDob() {
		return Dob;
	}
	public void setDob(String dob) {
		Dob = dob;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getFname() {
		return Fname;
	}
	public void setFname(String fname) {
		Fname = fname;
	}
	public String getLname() {
		return Lname;
	}
	public void setLname(String lname) {
		Lname = lname;
	}
	public String getIdType() {
		return IdType;
	}
	public void setIdType(String idType) {
		IdType = idType;
	}
	public String getAddressId() {
		return AddressId;
	}
	public void setAddressId(String addressId) {
		AddressId = addressId;
	}
	public String getSimId() {
		return SimId;
	}
	public void setSimId(String simId) {
		SimId = simId;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public Customer(String cid, String dob, String email, String fname, String lname, String idType, String addressId,
			String simId, String state) {
		super();
		Cid = cid;
		Dob = dob;
		Email = email;
		Fname = fname;
		Lname = lname;
		IdType = idType;
		AddressId = addressId;
		SimId = simId;
		State = state;
	}
	
}
