package com.example.SimActivation_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimActivation1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
