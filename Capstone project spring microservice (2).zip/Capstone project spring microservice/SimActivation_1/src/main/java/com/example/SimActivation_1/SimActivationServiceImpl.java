package com.example.SimActivation_1;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

//import com.SimActivation1.SimActivation1.Customers;

//import com.SimActivation1.SimActivation1.DetailsOfSimObj;
//import com.SimActivation1.SimActivation1.Offers;
@Service
public class SimActivationServiceImpl implements SimActivationService {

	// get data from database here,  we are defining it for this project
	List<SimOffers> sol=List.of(
			
			new SimOffers("1","100","100","11","Free calls and data1","1"),
			new SimOffers("2","100","100","10","Free calls and data2","1"),
			new SimOffers("1","100","100","11","Free calls and data1","2"),
			new SimOffers("2","100","100","10","Free calls and data2","2")
			
			);
	List<SimDetails> sdl=List.of(
			
			new SimDetails("1","1234567891","1234567891234","active"),
			new SimDetails("1","1234567892","1234567891235","Inactive"),
			new SimDetails("1","1234567893","1234567891236","active"),
			new SimDetails("1","1234567894","1234567891237","Inactive")
			
			
			
			);
	

	
	
	public boolean checkforchar(char ch)
	{
		if((int)ch-(int)'a'>26 || (int)ch-(int)'a'<0)
			return true;
		return false;
	}
	public boolean checkforemail(String s1)
	{
		char [] ch=s1.toCharArray();
		boolean ok=true;
		int start = 0;
		for(int i=0;i<ch.length;i++)
		{
			if(ch[i]=='@')
				{
				ok=false;
				start=i;
				break;
				
				}
		}
		if(ok==true)
		{
			return false;
			
		}
		ok=true;
		for(int i=start;i<ch.length;i++)
		{
			if(ch[i]=='.')
			{
				start=i;
				ok=false;
				break;
			}
		}
		if(ok==true)
			return false;
		if(ch.length-start<2 && ch.length-start>4)
		{
			return false;
		}
		
		return true;
	}
	public boolean checkfordate(String s1)
	{
		char [] ch1=s1.toCharArray();
		if(ch1[4]!='-' && ch1[7]!='-')
		{
			return false;
		}
		
		for(int i=0;i<ch1.length;i++)
		{
			if(i!=4 && i!=7)
			{
				if((int)ch1[i]-(int)'0' >9 || (int)ch1[i]-(int)'0' <0)
				{
					return false;
				}
					
			}
		}
		return true;
	}
	@Override
	public List<SimOffers> service1(String sim_no, String service_no) {
		// TODO Auto-generated method stub
		if(sim_no.length()!=13 || service_no.length()!=10)
		{
			System.out.println("Invalid Details");
			return null;
		}
		 String simid=new String();
		
		for(SimDetails s:sdl)
		{
			//System.out.println(s.getSim_no()+" "+sim_no);
			if(s.getSimNo().equals(sim_no)==true)
			{
				
				simid=s.getId();
				System.out.println(simid);
				
				if(service_no.equals(s.getServiceNo())==false)
				{
					System.out.println("Invalid Details");
					
					return null;
				}
				else if("active".equals(s.getSimStatus())==true)
				{
					System.out.println("Sim already exists");
					return null;
				}
					
			}
		}
		List<SimOffers> temp=new ArrayList<>();
		
		for(SimOffers o:sol)
		{
			if(o.getSimId().equals(simid))
				temp.add(o);
		}
		//System.out.println()
		return temp;
		
		//return null;
	}
	
	@Override
	public String getSimId(String s1) {
		// TODO Auto-generated method stub
		
		// String simid=new String();
			
			for(SimDetails s:sdl)
			{
				//System.out.println(s.getSim_no()+" "+sim_no);
				if(s.getSimNo().equals(s1)==true)
				{
					
					return s.getId();
					
				}
			}
		return null;
	}
	
	public String validate1 (String s1, String s2)
	{
		
		if(s1.length()==0 || s2.length()==0)
		{
			return "Email/Dob are mendatory";
		}
		
		if(checkforemail(s1)==false)
		{
			return "Invalid Email";
		}
		//check for dob
	
		
		if(checkfordate(s2)==false)
		{
			return "Invalid date";
		}
		
		
	
		return "Record Match";
		
	}
	
	public String validate2(String s1, String s2, String s3, String s4)
	{
		s1=s1.toLowerCase();
		s2=s2.toLowerCase();
		
		if(s1.length()>15 || s2.length()>15)
			return "Invalid Fname/Lname";
		char [] ch1=s1.toCharArray();
		char [] ch2=s2.toCharArray();
		for(int i=0;i<ch1.length;i++)
		{
			if(checkforchar(s1.charAt(i)))
				return "Invalid Fname";
		}
		for(int i=0;i<ch2.length;i++)
		{
			if(checkforchar(s2.charAt(i)))
				return "Invalid Lname";
		}
		if(s3.equals(s4))
		{
			return "Valid Person";
		}
		else
			return "Invalid Person";
	}
	

	

}
