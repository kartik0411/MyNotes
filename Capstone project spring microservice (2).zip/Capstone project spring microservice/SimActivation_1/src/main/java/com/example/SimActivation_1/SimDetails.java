package com.example.SimActivation_1;

public class SimDetails {

	private String Id;
	private String ServiceNo;
	public SimDetails(String id, String serviceNo, String simNo, String simStatus) {
		super();
		Id = id;
		ServiceNo = serviceNo;
		SimNo = simNo;
		SimStatus = simStatus;
	}
	public SimDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	private String SimNo;
	private String SimStatus;
	public String getId() {
		return Id;
	}
	public void setId(String id) {
		Id = id;
	}
	public String getServiceNo() {
		return ServiceNo;
	}
	public void setServiceNo(String serviceNo) {
		ServiceNo = serviceNo;
	}
	public String getSimNo() {
		return SimNo;
	}
	public void setSimNo(String simNo) {
		SimNo = simNo;
	}
	public String getSimStatus() {
		return SimStatus;
	}
	public void setSimStatus(String simStatus) {
		SimStatus = simStatus;
	}
	
}
