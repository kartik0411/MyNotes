package com.example.SimActivation_1;

import java.util.List;

public interface SimActivationService {

	// this service will request for both sim and service no and do validations
	public List<SimOffers> service1(String simNo, String serviceNo);

	public String getSimId(String s1);
	public String validate1(String s1, String s2);

	public String validate2(String s1, String s2, String s3, String email);
	
	

}
