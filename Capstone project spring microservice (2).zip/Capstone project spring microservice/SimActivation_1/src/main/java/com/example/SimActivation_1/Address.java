package com.example.SimActivation_1;

public class Address {

	public Address() {
		// TODO Auto-generated constructor stub
	}
	private String Addressid;
	private String Address;
	private String City;
	private String Pin;
	private String State;
	public String getAddressid() {
		return Addressid;
	}
	public void setAddressid(String addressid) {
		Addressid = addressid;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getPin() {
		return Pin;
	}
	public void setPin(String pin) {
		Pin = pin;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public Address(String addressid, String address, String city, String pin, String state) {
		super();
		Addressid = addressid;
		Address = address;
		City = city;
		Pin = pin;
		State = state;
	}
}
