package com.example.SimActivation_1;

public class SimOffers {

	public SimOffers() {
		// TODO Auto-generated constructor stub
	}
	
	private String OfferId;
	private String CallQty;
	private String Cost;
	private String DataQty;
	private String OfferName;
	private String SimId;
	public String getOfferId() {
		return OfferId;
	}
	public void setOfferId(String offerId) {
		OfferId = offerId;
	}
	public String getCallQty() {
		return CallQty;
	}
	public void setCallQty(String callQty) {
		CallQty = callQty;
	}
	public String getCost() {
		return Cost;
	}
	public void setCost(String cost) {
		Cost = cost;
	}
	public String getDataQty() {
		return DataQty;
	}
	public void setDataQty(String dataQty) {
		DataQty = dataQty;
	}
	public String getOfferName() {
		return OfferName;
	}
	public void setOfferName(String offerName) {
		OfferName = offerName;
	}
	public String getSimId() {
		return SimId;
	}
	public void setSimId(String simId) {
		SimId = simId;
	}
	public SimOffers(String offerId, String callQty, String cost, String dataQty, String offerName, String simId) {
		super();
		OfferId = offerId;
		CallQty = callQty;
		Cost = cost;
		DataQty = dataQty;
		OfferName = offerName;
		SimId = simId;
	}
	

}
