package com.example.SimActivation_1;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

//import com.SimActivation1.SimActivation1.Offers;

@RestController
public class SimMsController {

	@Autowired
	private SimActivationService sas;
	private  String cur_simid="1";
	
	@Autowired
	private RestTemplate rt;
	
	
	
	@RequestMapping("/home/{id1}/{id2}")
	@HystrixCommand(fallbackMethod="fallback1")
	public List<SimOffers> home(@PathVariable("id1") String s1,@PathVariable("id2") String s2)
	{
		
	List<SimOffers> l1	= sas.service1(s1, s2);
	
	if(l1.size()!=0)
	{
	cur_simid=	sas.getSimId(s1);
	}
	
	return l1;
		
	//	return null;
		
	}
	// now application will call customer from customerMs
public	Customer curCustomer=new Customer();
//public ArrayList<Customer> l1=new ArrayList<>();
	@RequestMapping("/validate")
	@HystrixCommand(fallbackMethod="fallback2")
	public String Validate()
	{
		
	
	//	return "doing";
	Customer l1 = rt.getForObject("http://CustmerMs/customer/"+cur_simid,Customer.class);
		
	
		// here we get list of customer with sa,e id;
		//List<Customer> l1	= 
	//	curCustomer=(Customer)l1.get(0);
		//System.out.println(curCustomer.getEmail()+ l1.size());
	// System.out.println(l1.get(0));
	 
	 
	
//	return "doing";
		if(l1==null)
			return "No Record Match";
		
		curCustomer=l1;
		return sas.validate1(l1.getEmail(),l1.getDob());
		//return l1;
		
		
	}
	
	// the current customer is saved locally now ask for first name and lastname and email id;
	
	
	@RequestMapping("/validate2/{id1}/{id2}/{id3}")
	public String UserService5(@PathVariable("id1") String s1,@PathVariable("id2") String s2,@PathVariable ("id3")String s3)
	{
		
		return sas.validate2(s1,s2,s3,curCustomer.getEmail());
		
	//return null;
		
	}
	//add shipping address, this will return address which will be recieved in AddressMs
	
	@RequestMapping("/fill-address/{id1}/{id2}/{id3}/{id4}")
	@HystrixCommand(fallbackMethod="fallback3")
	public Address UserService6(@PathVariable("id1") String s1,@PathVariable("id2") String s2,@PathVariable ("id3")String s3,@PathVariable ("id4")String s4)
	{
		
		Address a1= new Address("0",s1,s2,s3,s4);
		
		return a1;
		
	//return null;
		
	}
	
	public List<SimOffers> fallback1(String s1, String s2, String s3, String s4)
	{
		List<SimOffers> l1=new ArrayList<>();
		return l1;
	}
	
	public String fallback2()
	{
		return "Something Went Wrong";
	}
	
	public Address fallback3(String s1, String s2,String s3,String s4)
	{
		Address a=new Address();
		return a;
		
	}
	
}
