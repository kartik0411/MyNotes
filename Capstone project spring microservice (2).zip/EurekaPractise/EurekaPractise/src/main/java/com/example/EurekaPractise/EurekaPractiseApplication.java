package com.example.EurekaPractise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class EurekaPractiseApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekaPractiseApplication.class, args);
	}

}
