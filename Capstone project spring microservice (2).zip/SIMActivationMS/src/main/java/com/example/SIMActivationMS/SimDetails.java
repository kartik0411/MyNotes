package com.example.SIMActivationMS;

public class SimDetails {

	public SimDetails() {
		// TODO Auto-generated constructor stub
	}
	

}
