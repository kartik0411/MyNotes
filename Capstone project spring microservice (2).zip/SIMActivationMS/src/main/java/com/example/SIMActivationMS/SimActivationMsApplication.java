package com.example.SIMActivationMS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimActivationMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimActivationMsApplication.class, args);
		System.out.println("SIM ACtivation RUNNING");
	}

}
