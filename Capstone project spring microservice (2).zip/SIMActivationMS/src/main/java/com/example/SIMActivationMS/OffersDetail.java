package com.example.SIMActivationMS;

public class OffersDetail {

	public OffersDetail() {
		// TODO Auto-generated constructor stub
	}

}
