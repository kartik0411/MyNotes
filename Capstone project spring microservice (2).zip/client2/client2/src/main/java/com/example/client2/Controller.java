package com.example.client2;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {
	
	@Autowired
	private service2 s2;
	@CrossOrigin("http://localhost:4200")
	@GetMapping("/client2/{id}")
	public Contact  findit(@PathVariable String id)
	{
		Contact l1= s2.getContact(id);
		
		System.out.println(id);
		return l1;
	}

}
