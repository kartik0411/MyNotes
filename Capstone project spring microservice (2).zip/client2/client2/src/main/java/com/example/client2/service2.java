package com.example.client2;

import java.util.List;

public interface service2 {

	Contact getContact(String Id);
	
}
