package com.example.client2;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class ServiceImpl implements service2 {

	
	List<Contact> l1=List.of(new Contact("praveen","123456789","121"),new Contact("poop","91123456789","122"),new Contact("praveenpp","456789","121"),new Contact("praveen","1277779","122") );
	@Override
	public Contact getContact(String Id) {
		// TODO Auto-generated method stub
		
	//	List<Contact> ans=new ArrayList<>();
		
		for(Contact c:l1)
		{
			System.out.println(Id+" "+c.getId());
			if(c.getId().equals(Id))
			{
				//System.out.println(c.getName());
				return c;
			}
		}
		return null;
	}

}
