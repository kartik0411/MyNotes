package com.example.client2;

public class Contact {

	
	private String name;
	private String ph;
	private String id;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPh() {
		return ph;
	}
	public void setPh(String ph) {
		this.ph = ph;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Contact() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Contact(String name, String ph, String id) {
		super();
		this.name = name;
		this.ph = ph;
		this.id = id;
	}
}
