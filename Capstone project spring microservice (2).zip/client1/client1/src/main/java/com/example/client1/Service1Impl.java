package com.example.client1;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class Service1Impl implements Service1 {
	
	
	List<person> l1=List.of(
			new person("praveen","121"),
			new person("Shipra","123"),
			new person("praveen pathak","124"),
			new person("sunil","125")
			
			);

	@Override
	public person getperson(String id) {
		// TODO Auto-generated method stub
		
		for(person p:l1)
		{
			if(p.getId().equals(id))
			{
				return p;
				
			}
		}
		return null;
	}

}
