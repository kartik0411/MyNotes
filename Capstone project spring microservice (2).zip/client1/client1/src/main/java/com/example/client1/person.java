package com.example.client1;

import java.util.List;

public class person {
	
	private String  Name;
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getId() {
		return Id;
	}
	public void setId(String id) {
		Id = id;
	}
	public List<Contact> getContactList() {
		return contactList;
	}
	public void setContactList(List<Contact> contactList) {
		this.contactList = contactList;
	}
	public person(String name, String id) {
		super();
		Name = name;
		Id = id;
	//	this.contactList = contactList;
	}
	private String Id;
	List<Contact> contactList;
	public person() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
