package com.example.client1;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
//@ComponentScan("com.example.client1")
public class Controller1 {
	
	
	@Autowired
	private Service1 s1;
	@Autowired
	private RestTemplate rt;
	
	
	@GetMapping("/client/{id}")
	public person check(@PathVariable ("id") String id)
	{
	Contact c=	rt.getForObject("http://Client2/client2/122", Contact.class);
	
	List<Contact> l1=new ArrayList<>();
	l1.add(c);
	System.out.println(c.getId());
	person p=s1.getperson(id);
	p.setContactList(l1);
	
	return p;
	
	}

}
