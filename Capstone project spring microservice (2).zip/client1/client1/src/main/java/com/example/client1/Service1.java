package com.example.client1;

public interface Service1 {
	
	
	person getperson(String id);

}
