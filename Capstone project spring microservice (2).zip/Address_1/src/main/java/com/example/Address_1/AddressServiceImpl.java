package com.example.Address_1;

import java.util.List;

import org.springframework.stereotype.Service;
@Service
public class AddressServiceImpl implements AddressService {

	public AddressServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	List<Address> AddressList=List.of(new Address());
	@Override
	public void feed(Address a1) {
		// TODO Auto-generated method stub
		
		AddressList.add(a1);
		
	}

}
