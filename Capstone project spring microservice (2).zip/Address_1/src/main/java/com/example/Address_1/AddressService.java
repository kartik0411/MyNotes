package com.example.Address_1;

public interface AddressService {

	void feed(Address a1);

}
