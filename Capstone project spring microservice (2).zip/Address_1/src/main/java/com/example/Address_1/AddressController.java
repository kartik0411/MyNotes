package com.example.Address_1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

//import com.example.SimActivation_1.Address;

@RestController
public class AddressController {

	@Autowired
	private AddressService as;
	@Autowired
	private RestTemplate rt;
	@RequestMapping("/address/fill-address/{id1}/{id2}/{id3}/{id4}")
	public Address UserService6(@PathVariable("id1") String s1,@PathVariable("id2") String s2,@PathVariable ("id3")String s3,@PathVariable ("id4")String s4)
	{
		
		Address a1= rt.getForObject("http://SimMs/fill-address/1/2/3/4", Address.class);
		as.feed(a1);
		
		
		return a1;
		
	//return null;
		
	}
}
