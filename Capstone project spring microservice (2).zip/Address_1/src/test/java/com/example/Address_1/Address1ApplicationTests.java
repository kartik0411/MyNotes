package com.example.Address_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Address1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
