package com.example.AdderssMs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdderssMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdderssMsApplication.class, args);
		System.out.println("Address Ms Running");
	}

}
