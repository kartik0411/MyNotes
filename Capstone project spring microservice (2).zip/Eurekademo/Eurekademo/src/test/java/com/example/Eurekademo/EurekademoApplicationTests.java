/*package com.example.Eurekademo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekademoApplicationTests {

	@Test
	void contextLoads() {
	}

}
*/